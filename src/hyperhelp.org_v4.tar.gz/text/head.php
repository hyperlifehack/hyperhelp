<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta lang="en" name="description" content="hyperhelp.org is a Platform, were committed people so called do-gooder can anonymously (use the tor browser bundle!) track their (moneyless) efforts and commitment to society - to make it transparent to society and hopefully valued." />
<meta lang="de" name="description" content="hyperhelp.org ist eine Platform, welche es dem engagierten Gutmenschen / Ehrenamtlichen erlaubt ihre eigene (Geldlosen) Leistungen an der Gesellschaft zu erfassen und auszuwerten und das ganze auch anonym. (Tor Bundle Browser verwenden!)" />

<meta lang="en" name="keywords" content="Book-keeping, do-gooder, committed, commitment, capture, time recording" />
<meta lang="de" name="keywords" content="Buchhaltung, Gutmensch, engagiert, engagement, festhalten, erfassen, zeitcapture" />
<meta lang="es" name="keywords" content="Libro de mantenimiento, bienhechora, comprometido, el compromiso, la captura, el tiempo de grabación" />

<!-- apple-iphone specific stuff -->
<meta name="apple-mobile-web-app-capable" content="yes"/>
<meta name="apple-mobile-web-app-status-bar-style" content="white">
<link rel="apple-touch-icon" href="images/star.png"/>

<title>hyperhelp.org - want to help?</title>

<!-- external styles -->
<link href="css/style.css" type="text/css" rel="stylesheet" />
<link href="css/shariff.min.css" type="text/css" rel="stylesheet" />