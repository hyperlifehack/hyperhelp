			<div id="headline" class="boxShadows" title="for security: works without Javascript :-D">
				
				<h1>
					<div id="headline_text">hyperhelp.org</div>
				</h1>
				<p>Here you can do book-keeping of your commitment to make mankind a better one, <br> and make it transparent to your community so it can be valued :)</p>
				<p>Hier kannst Du dein Engagement erfassen, <br> damit es gewertschätzt und nicht vergessen wird :)</p>
			</div>
