# hyperhelp

hyper help helps you to help - you help me - i help you - everybody helps everybody - opensource - one and for all.