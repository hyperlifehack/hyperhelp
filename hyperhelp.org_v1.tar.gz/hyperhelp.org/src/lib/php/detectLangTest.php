<?php
	include 'detectLang.php';
	$lang = detectLang("verbose");
	$self = $_SERVER['SCRIPT_NAME'];
?>